#
# Cookbook Name:: SII
# Recipe:: default
#
# Copyright 2017, YOUR_COMPANY_NAME
#
# All rights reserved - Do Not Redistribute
#
powershell_script 'iis' do
code <<-EOH
import-module ServerManager
Add-WindowsFeature Web-Server
Add-WindowsFeature Web-Lgcy-Mgmt-Console
EOH
end
