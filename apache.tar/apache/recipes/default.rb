package "httpd" do
  action :install
end
script "apacheinstall" do
interpreter "bash"
code <<-EOH
service httpd start
EOH
end

file '/var/www/html/index.html' do
content '<html>
<body>
 <h1>hello world</h1>
</body>
</html>'
end

